package Car;

public class CarDbModel {
	
	//추가
	public void insertCar()
	{
		
	}
	
	//삭제
	
	
	//수정
	
	
	//조회


}
