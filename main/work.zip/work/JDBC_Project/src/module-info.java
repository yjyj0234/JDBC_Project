/**
 * 
 */
/**
 * 
 */
module JDBC_Project {
	requires java.desktop;
	requires java.sql;
}